print_int 5 ;;
print_newline() ;;

(* Déréférencement d'une référence *)
let a : int ref = ref 5 ;;
print_int !a ;;
