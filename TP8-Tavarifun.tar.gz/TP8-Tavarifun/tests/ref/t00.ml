print_int 3 ;;
print_newline() ;;

(* Définition d'une référence *)
let a : int ref = ref 1 ;;
print_int 3 ;;
