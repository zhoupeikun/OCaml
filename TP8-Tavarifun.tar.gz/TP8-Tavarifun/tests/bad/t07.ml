(* Incohérence UNIT vs INT *)
let a = print_int 3 in print_int a ;;
