(* Incohérence INT vs UNIT *)
if true then 3 else print_int 3 ;;
