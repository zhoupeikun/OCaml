(* Incohérence INT vs BOOL *)
print_int (1 + true) ;;
