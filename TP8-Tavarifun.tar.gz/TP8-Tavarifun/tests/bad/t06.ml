(* Incohérence UNIT vs INT *)
let a = () in print_int a ;;
