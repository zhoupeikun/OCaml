(* Incohérence BOOL vs INT *)
let f (x: bool) : int = x ;;
print_int (f true) ;;
