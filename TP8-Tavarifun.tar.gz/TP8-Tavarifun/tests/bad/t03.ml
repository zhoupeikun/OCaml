(* Incohérence INT vs BOOL *)
if 1 + 4 then print_int 2 else print_int 3 ;;
