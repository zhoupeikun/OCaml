(* Incohérence UNIT vs BOOL *)
print_newline false ;;
