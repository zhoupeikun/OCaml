(* Incohérence BOOL vs INT *)
let a = true || false in
let b = a in
print_int a ;;
