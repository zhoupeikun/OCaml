(* Incohérence BOOL vs INT *)
let a : bool = true ;;
print_int (a * 2) ;;
