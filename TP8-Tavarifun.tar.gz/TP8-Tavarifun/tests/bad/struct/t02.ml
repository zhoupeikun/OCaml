type pair = { left: int; right: int } ;;
let a : pair = { left = 1; right = 2 } ;;
if a.left then print_int 1 else print_int 2 ;;
