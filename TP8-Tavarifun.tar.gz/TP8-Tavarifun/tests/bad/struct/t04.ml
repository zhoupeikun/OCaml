type pair = { left: int; right: int } ;;
let a : pair = { left = 1; mutable right = 2 } ;;
a.right <- false ;;
