type pair = { left: int; right: int } ;;
let a : pair = { left = 1; right = true } ;;
