type pair = { left: int; right: int } ;;
print_int 1.left ;;
