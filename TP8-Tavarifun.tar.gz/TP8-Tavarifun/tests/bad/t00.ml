(* Incohérence INT vs UNIT. *)
let a : int = () ;;
