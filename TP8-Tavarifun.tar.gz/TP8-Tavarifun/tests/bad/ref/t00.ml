let a : int ref = ref 1 ;;
print_int a ;;
