let a : int ref = 1 ;;
print_int !a ;;
