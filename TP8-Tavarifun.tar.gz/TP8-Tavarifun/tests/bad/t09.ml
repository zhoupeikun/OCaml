(* Incohérence BOOL vs INT *)
let f (x: bool) : bool = x ;;
print_int (f true) ;;
