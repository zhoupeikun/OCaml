print_int 5 ;;
print_newline () ;;

(* Définition d'options. *)
let x : bool option = None ;;
let y : int option = Some 3 ;;
print_int 5 ;;
