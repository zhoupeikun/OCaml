print_int 38 ;;
print_newline () ;;

(* Définition de types records. *)
type pair   = { gauche : int; droite : int } ;;
print_int 3 ;;
type triple = { tete : int; queue : pair } ;;
print_int 8 ;;
