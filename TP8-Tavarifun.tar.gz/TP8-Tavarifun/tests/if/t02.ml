print_int 235710 ;;
print_newline () ;;

(* Test d'égalité et comparaisons. *)
if 12 == 25 then print_int 1 else print_int 2 ;;
if 12 != 25 then print_int 3 else print_int 4 ;;
if 12  < 25 then print_int 5 else print_int 6 ;;
if 25 <= 25 then print_int 7 else print_int 8 ;;
if 12 >= 25 then print_int 9 else print_int 10 ;;
