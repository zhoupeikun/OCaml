print_int 2 ;;
print_newline () ;;

(* Définition d'une fonction. *)
let f (x: int) (y: bool) (z: int) : int = x + 1 ;;
print_int 2 ;;
