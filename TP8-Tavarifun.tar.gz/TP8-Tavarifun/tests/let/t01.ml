print_int 1 ;;
print_newline () ;;

(* Lecture d'une variable globale. *)
let a : int = 1 ;;
print_int a ;;
