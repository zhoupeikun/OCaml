print_int 0 ;;
print_newline () ;;

(* Allocation d'une variable globale. *)
let a : int = 1 ;;
print_int 0 ;;
