print_int 3 ;;
print_newline () ;;

(* Addition. *)
print_int (1 + 2) ;;
