print_int 2046 ;;
print_newline () ;;

(* Arithmétique, la totale. *)
print_int (3 + 2 * (3 + 2 * 3) - 1) ;;
print_int (13 / 3) ;;
print_int (-2 + 64 / 8) ;;
