print_int 7 ;;
print_newline () ;;

(* Addition, multiplication et priorité. *)
print_int (1 + 2 * 3) ;;
