print_int 9 ;;
print_newline () ;;

(* Addition et multiplication. *)
print_int ((1 + 2) * 3) ;;
